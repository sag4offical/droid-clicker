const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.TiledBg,
		C3.Plugins.Sprite,
		C3.Plugins.Mouse,
		C3.Plugins.Text,
		C3.Plugins.Button,
		C3.Plugins.Audio,
		C3.Plugins.Keyboard,
		C3.Plugins.Browser,
		C3.Plugins.Mouse.Cnds.OnObjectClicked,
		C3.Plugins.System.Acts.AddVar,
		C3.Plugins.System.Cnds.EveryTick,
		C3.Plugins.Text.Acts.SetText,
		C3.Plugins.Button.Cnds.OnClicked,
		C3.Plugins.System.Acts.SetVar,
		C3.Plugins.Audio.Acts.Play,
		C3.Plugins.Keyboard.Cnds.IsKeyDown,
		C3.Plugins.System.Acts.GoToLayout,
		C3.Plugins.System.Acts.Wait,
		C3.Plugins.System.Acts.RestartLayout,
		C3.Plugins.Browser.Acts.Close
	];
};
self.C3_JsPropNameTable = [
	{TiledBackground: 0},
	{Sprite: 0},
	{Mouse: 0},
	{Text: 0},
	{Text2: 0},
	{resetButton: 0},
	{droid: 0},
	{TiledBackground2: 0},
	{Button: 0},
	{Sprite2: 0},
	{Text3: 0},
	{Keyboard: 0},
	{Sprite3: 0},
	{Browser: 0},
	{Button2: 0},
	{score: 0}
];

self.InstanceType = {
	TiledBackground: class extends self.ITiledBackgroundInstance {},
	Sprite: class extends self.ISpriteInstance {},
	Mouse: class extends self.IInstance {},
	Text: class extends self.ITextInstance {},
	Text2: class extends self.ITextInstance {},
	resetButton: class extends self.IButtonInstance {},
	droid: class extends self.IInstance {},
	TiledBackground2: class extends self.ITiledBackgroundInstance {},
	Button: class extends self.IButtonInstance {},
	Sprite2: class extends self.ISpriteInstance {},
	Text3: class extends self.ITextInstance {},
	Keyboard: class extends self.IInstance {},
	Sprite3: class extends self.ISpriteInstance {},
	Browser: class extends self.IInstance {},
	Button2: class extends self.IButtonInstance {}
}